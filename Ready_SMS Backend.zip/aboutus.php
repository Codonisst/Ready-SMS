<!DOCTYPE html>
<html lang="en">

<head>
    <title>About us</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Latest compiled and minified JavaScript -->
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css">
    <!-- Font-Awesome icons-->
    <link rel="stylesheet" href=https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css> <link
        rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60e5f0a9d6e7610a49aa2104/1fa138618';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<body>

    <!----------------HEADER-------------------->
    <div class="navigation-bar">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#"><img src="assets/img/logo.svg"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-sms.php">BULK SMS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutus.php">ABOUT US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-software.php">BULK SOFTWARE</a>
                        </li>
                        <!--<li class="nav-item">
                            <a class="nav-link" href="bulk-packages.php">BULK PACKAGES</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="faq.php">FAQ's</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us.php">CONTACT US</a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="http://72.21.24.203:90/Readyfone/"><button type="btn" class="login-btn" id="btn">LOGIN</button></a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="https://readysms.net/portal"><button type="btn" id="btn">LOGIN RESELLER</button></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <!-- ------------ ABOUT PAGE --------------->
    <div class="about-page-sec1">
        <div class="page-title">
            <h2>About Us</h2>
        </div>
        <div class="about-content mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about-text">
                            <h2>It's All About Us <br></h2>
                                <p>ReadySMS is a quality service of "ReadySolutions". We are providing best Telecom services worldwide with Readyfone to contact peoples with cheap rates and pure crystal qualities. ReadySMS is also a unique product to maintain market needs for whitelable /Branding SMS services. We never compromise with quality routes & termination services .</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about-image">
                            <img src="assets/img/ourportal.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="about-page-sec2 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="about-text">
                        <h2>Mission</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi et impedit perferendis aliquam praesentium vel alias dicta adipisci sint suscipit quis laborum nemo libero quam, eius quisquam tempore, rerum ratione? impedit adipisci voluptatibus dolorum tempora itaque explicabo quis a atque excepturi eaque quo. Illum, iste?</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about-text">
                        <h2>LOREM </h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi et impedit perferendis aliquam praesentium vel alias dicta adipisci sint suscipit quis laborum nemo libero quam, eius quisquam tempore, rerum ratione? impedit adipisci voluptatibus dolorum tempora itaque explicabo quis a atque excepturi eaque quo. Illum, iste?</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ----------FOOTER SECTION ------------ -->
    <footer class="footer-section">
        <div class="container">
            <div class="footer-bottom">
                <div class="row pt-5">
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_mail.svg" alt="Image">
                                        <p>sales@readysms.net</p>
                                        <span>Our Mailbox</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="social-links contact-links mt-5">
                            <ul class="abc">
                                <li><a href="https://wa.me/0019188444178"><i class="fa fa-whatsapp"></i></a></li>
                                <li><a href="https://facebook.com/readysms/"><i class="fa fa-facebook-f"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_call.svg" alt="Image">
                                        <p>+191 88 444 178</p>
                                        <span>Our Phone</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="copyrights">
                    <p>Copyrights 2019 © ReadySMS, Designed and Developed by Swismax Solution All
                        rights reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="" src="assets/js/owl.carousel.min.js"></script>
    <script type="" src="assets/js/owl.carousel.setting.js"></script>
    <script type="" src="assets/js/main.js"></script>
</body>

</html>