<!DOCTYPE html>
<html lang="en">

<head>
    <title>ReadySMS</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Latest compiled and minified JavaScript -->
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css">
    <!-- Font-Awesome icons-->
    <link rel="stylesheet" href=https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css> <link
        rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60e5908bd6e7610a49aa0eac/1fa0bp8rv';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</head>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60e5f0a9d6e7610a49aa2104/1fa138618';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<body>
<!---------------------- THE START ---------------------------->

 <!------------HEADER--------------->
 <div class="navigation-bar">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#"><img src="assets/img/logo.svg"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?view=bulk_sms">BULK SMS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?view=aboutus">ABOUT US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?view=bulk_software">BULK SOFTWARE</a>
                        </li>
                        <!--<li class="nav-item">
                            <a class="nav-link" href="index.php?view=bulk_packages">BULK PACKAGES</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="index.php?view=faq">FAQ's</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?view=contact_us">CONTACT US</a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="http://72.21.24.203:90/Readyfone/"><button type="btn" class="login-btn" id="btn">LOGIN</button></a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="https://readysms.net/portal"><button type="btn" id="btn">LOGIN RESELLER</button></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

