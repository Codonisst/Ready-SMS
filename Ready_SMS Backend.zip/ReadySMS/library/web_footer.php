

<!-- ----------FOOTER SECTION ------------ -->
<footer class="footer-section">
        <div class="container">
            <div class="footer-bottom">
                <div class="row pt-5">
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_mail.svg" alt="Image">
                                        <p>sales@readysms.net</p>
                                        <span>Our Mailbox</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="social-links contact-links mt-5">
                            <ul class="abc">
                                <li><a href="https://wa.me/0019188444178"><i class="fa fa-whatsapp"></i></a></li>
                                <li><a href="https://facebook.com/readysms/"><i class="fa fa-facebook-f"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_call.svg" alt="Image">
                                        <p>+191 88 444 178</p>
                                        <span>Our Phone</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="copyrights">
                    <p>Copyrights 2019 © ReadySMS, Designed and Developed by Swismax Solution All
                        rights reserved</p>
                </div>
            </div>
        </div>
    </footer>

 <!---------------------- THE END ---------------------------->
 <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="" src="assets/js/owl.carousel.min.js"></script>
    <script type="" src="assets/js/owl.carousel.setting.js"></script>
    <script type="" src="assets/js/main.js"></script>
</body>

</html>