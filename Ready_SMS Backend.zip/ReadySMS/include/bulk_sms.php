
    <!------------- BULK SMS PAGE --------------->
    <div class="bulk-sms-page">
        <div class="page-title">
            <h2>BULK SMS</h2>
        </div>
        <div class="bulk-page">
            <div class="container">
                <div class="bulk-content">
                    <div class="free-testing">
                        <!-- <h1>🥇BEST BULK SMS SERVICE PROVIDER IN INDIA (FREE TESTING)</h1> -->
                        <p><b>Bulk SMS</b> needs no introduction. We all know that SMS stands for Short Messaging
                            Service.
                            Basically it means sending text messages from phone/laptop to another phone and when we send
                            SMS
                            to group of people then it called as Bulk SMS. To send SMS people use <b>Bulk SMS
                                service.</b>
                        </p>
                    </div>
                    <div class="send-sms">
                        <a href="contact-us.php"><img src="assets/img/send-sms.png" alt="Image"></a>
                    </div>
                    <div class="bulk-text">
                        <!-- <p><b>What exactly is bulk SMS?</b> And what are the kinds of bulk SMS which are getting so
                            popular that every business or industry is planning to implement <a href="#">bulk SMS
                                advertising</a> strategy? Let’s dig deep into these questions.</p>

                        <h3>What is bulk SMS service?</h3>
                        <p>Wikipedia defines bulk SMS as the dissemination of large number of SMS messages for delivery
                            to mobile phone terminals. To put in simple words it means that bulk SMS is sending SMS to
                            large number of recipients at once. Bulk SMS can be used to send reminders, alerts, update
                            clients about new offers, deals, and discounts. These days it is widely used for promotion
                            and advertising of products and services. <br>
                            There is no limit to the use of bulk SMS. Its uses are endless. Bulk SMS can be deployed
                            wherever we need to build an instant connection and convey urgent information.</p> -->
                        <h3>Types of Bulk SMS Service</h3>
                        <ol>
                            <li>
                                <p><b>Transactional Bulk SMS Service</b> – These SMS are used for conveying certain
                                    urgent and necessary information. Example when message comes from a bank informing
                                    you about the amount credited or debited. Similarly when you make an online
                                    purchase, its details like invoice number, delivery status are being conveyed to you
                                    via an SMS.

                                </p>

                                <p><b>Example</b> <br> Dear Customer Rs. 500 was spent on Card no xxxx7899xxxx at
                                    Mumbai. Available balance in your account is Rs. 1000.</p>
                                <p>Dear Customer Your Amazon order is out for delivery. Please share the OTP 122944 with
                                    the Delivery agent to get the package.</p>
                            </li>
                            <li>
                                <p><b>Promotional Bulk SMS Service</b> – The basic purpose of the promotional SMS is to
                                    advertise a business and market its products and services. As per TRAI regulations,
                                    promotional SMS can be sent only to non DND number within a time frame of 9 AM to 9
                                    PM.</p>

                                <p> <b>Example</b> <br> Buy 2 kitchen appliances and get 1 at 50% discount. Hurry up.
                                    Offer valid till the stock lasts.</p>
                                <p> Now you must be clear regarding the difference between the <b>promotional and the
                                        transactional Bulk SMS.</b> Let’s compare <b>bulk SMS marketing</b> with other
                                    prevailing forms of marketing.</p>
                            </li>
                        </ol>
                        <h3>Bulk SMS vs email marketing</h3>
                        <p>There is a lot of debate on the topic whether to go for bulk SMS or email marketing. Let’s
                            look into some facts related to email and SMS:</p>
                        <div class="email image">
                            <a href="#"><img src="assets/img/text-read.png" alt="Image"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
