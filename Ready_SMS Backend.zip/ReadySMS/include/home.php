
    
    <!---------HERO SECTION-------------->
    <section class="hero-section">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/img/slide_02.png" class="d-block w-100" alt="Image">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slide_02.png" class="d-block w-100" alt="Image">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slide_02.png" class="d-block w-100" alt="Image">
                </div>
            </div>
            <!-- <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon arrow" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon arrow" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a> -->
        </div>
    </section>

    <!------------- REGISTRAION SECTION --------------->
    <section class="registration-section">
        <div class="container">
            <div class="row reg-content">
                <div class="col-md-7">
                    <h3>ReadySMS allows you to quickly and easily send SMS</h3>
                    <p>ReadySMS providing Bulk SMS services for all types of marketing, promotional, branding, advertising & Transactional purposes. With ReadySMS you can access thousands clients within seconds to share a single message with all. Our Fast services will touch in few seconds to your receiver contacts.</p>
                </div>
                <div class="col-md-5">
                    <div class="reg-icon">
                        <a href="callto:+123123123"><img src="assets/img/readyfon.png" alt="image-butten"></a> &nbsp;
                        <a href="contact-us.php"><img src="assets/img/icon_getintouch.svg" alt="image-butten"></a>
                    </div>                
                    <!-- <p>ReadySMS providing Bulk SMS services for all types of marketing, promotional, branding, advertising & Transactional purposes. With ReadySMS you can access thousands clients within seconds to share a single message with all. Our Fast services will touch in few seconds to your receiver contacts.</p> -->
                </div>
            </div>
        </div>
    </section>

    <!-- -------- FEATURED SECTION ---------- -->
    <section class="feature-app">
        <div class="container">
            <h2 class="section-title mt-5">Our App Features
                <hr>
            </h2>
            <div class="row mt-5">
                <div class="col-md-6">
                    <div class="feature-portal">
                        <ul>
                            <li><a href="#"><img src="assets/img/feature_icon_01.svg" alt="Image">
                                    <div class="feature-text">
                                        <b>
                                            <p>BULK SMS</p>
                                        </b>
                                        <span>Send Transactional & Promotional SMS</span>
                                    </div>
                                </a></li>
                            <li><a href="#"><img src="assets/img/feature_icon_02.svg" alt="Image">
                                    <div class="feature-text">
                                        <b>
                                            <p>API SMS</p>
                                        </b>
                                        <span>Send OTP & Notification via SMS API</span>
                                    </div>
                                </a></li>
                            <li><a href="#"><img src="assets/img/feature_icon_03.svg" alt="Image">
                                    <div class="feature-text">
                                        <b>
                                            <p>SCHEDULED SMS</p>
                                        </b>
                                        <span>Sheduled Your SMS for Future Reminders</span>
                                    </div>
                                </a></li>
                            <li><a href="#"><img src="assets/img/feature_icon_04.svg" alt="Image">
                                    <div class="feature-text">
                                        <b>
                                            <p>CUSTOM SMS</p>
                                        </b>
                                        <span>Import Bulk Data From Your Excil File</span>
                                    </div>
                                </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-image">
                        <img src="assets/img/ourportal.png" alt="Image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- -----------DIGIT SECTION ------------->
    <!-- <section class="digits-section mt-5">
        <div class="container">
            <div class="row digit-item">
                <div class="col-md-4">
                    <div class="digit-text">
                        <h2><img src="assets/img/counter_icon.svg" alt="image-icon"> Doing the right thing, at the right
                            time.</h2>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="3000" data-speed="1500">5,426</h2>
                                <p class="count-text ">Clients</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="105" data-speed="1500">256</h2>
                                <p class="count-text ">Countries</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="1589" data-speed="1500">1,589</h2>
                                <p class="count-text ">SMS Sents</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="568" data-speed="1500">289</h2>
                                <p class="count-text ">Corporate Componies</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <section class="digits-section pb-5">
        <div class="container">
            <div class="digit-item">
                <div class="digit-text">
                    <img src="assets/img/counter_icon.svg" alt="image-icon"> &nbsp;
                    <h2> Doing the right thing, at the
                        right time.</h2>
                </div>
                <div class="digit-counter" id="clients-timer">
                    <div class="counter">
                        <h2 class="timer count-title count-number" data-to="3000" data-speed="1500">5,426</h2>
                        <p class="count-text ">Clients</p>
                    </div>
                    <div class="counter">
                        <h2 class="timer count-title count-number" data-to="105" data-speed="1500">256</h2>
                        <p class="count-text ">Countries</p>
                    </div>
                    <div class="counter">
                        <h2 class="timer count-title count-number" data-to="2983309" data-speed="1500">1,589</h2>
                        <p class="count-text ">SMS Sents</p>
                    </div>
                    <div class="counter">
                        <h2 class="timer count-title count-number" data-to="568" data-speed="1500">289</h2>
                        <p class="count-text ">Corporate Componies</p>
                    </div>
                </div>
                <!-- <div class="digit-timer">

                        </div> -->
                <!-- <div class="col-md-2">
                        <div class="counter">
                            <h2 class="timer count-title count-number" data-to="3000" data-speed="1500">5,426</h2>
                            <p class="count-text ">Clients</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="counter">
                            <h2 class="timer count-title count-number" data-to="105" data-speed="1500">256</h2>
                            <p class="count-text ">Countries</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="counter">
                            <h2 class="timer count-title count-number" data-to="2983309" data-speed="1500">1,589</h2>
                            <p class="count-text ">SMS Sents</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="counter">
                            <h2 class="timer count-title count-number" data-to="568" data-speed="1500">289</h2>
                            <p class="count-text ">Corporate Componies</p>
                        </div>
                    </div> -->

            </div>
        </div>
    </section>

    

   