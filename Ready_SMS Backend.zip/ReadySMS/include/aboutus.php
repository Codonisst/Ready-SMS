
    <!-- ------------ ABOUT PAGE --------------->
    <div class="about-page-sec1">
        <div class="page-title">
            <h2>About Us</h2>
        </div>
        <div class="about-content mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about-text">
                            <h2>It's All About Us <br></h2>
                                <p>ReadySMS is a quality service of "ReadySolutions". We are providing best Telecom services worldwide with Readyfone to contact peoples with cheap rates and pure crystal qualities. ReadySMS is also a unique product to maintain market needs for whitelable /Branding SMS services. We never compromise with quality routes & termination services .</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about-image">
                            <img src="assets/img/ourportal.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="about-page-sec2 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="about-text">
                        <h2>Mission</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi et impedit perferendis aliquam praesentium vel alias dicta adipisci sint suscipit quis laborum nemo libero quam, eius quisquam tempore, rerum ratione? impedit adipisci voluptatibus dolorum tempora itaque explicabo quis a atque excepturi eaque quo. Illum, iste?</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about-text">
                        <h2>LOREM </h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi et impedit perferendis aliquam praesentium vel alias dicta adipisci sint suscipit quis laborum nemo libero quam, eius quisquam tempore, rerum ratione? impedit adipisci voluptatibus dolorum tempora itaque explicabo quis a atque excepturi eaque quo. Illum, iste?</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
