
    <!-----------BULK PACKAGES--------------->

    <div class="bulk-packges">
        <div class="page-title">
            <h2>BULK PACKAGES</h2>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <ul class="price mt-5">
                        <li class="header">Basic</li>
                        <li class="grey">$ 9.99 / year</li>
                        <li>10GB Storage</li>
                        <li>10 Emails</li>
                        <li>10 Domains</li>
                        <li>1GB Bandwidth</li>
                        <li class="grey"><a href="#" class="button">Sign Up</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="price mt-5">
                        <li class="header" style="background-color:#FECA0A">Pro</li>
                        <li class="grey">$ 24.99 / year</li>
                        <li>25GB Storage</li>
                        <li>25 Emails</li>
                        <li>25 Domains</li>
                        <li>2GB Bandwidth</li>
                        <li class="grey"><a href="#" class="button">Sign Up</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="price mt-5">
                        <li class="header">Premium</li>
                        <li class="grey">$ 49.99 / year</li>
                        <li>50GB Storage</li>
                        <li>50 Emails</li>
                        <li>50 Domains</li>
                        <li>5GB Bandwidth</li>
                        <li class="grey"><a href="#" class="button">Sign Up</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
