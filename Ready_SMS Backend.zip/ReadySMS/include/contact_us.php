
     <!--------------CONTACT US PAGE-------------->
    <section class="contact-section">
        <div class="page-title">
            <h2>Contact Us</h2>
        </div>
        <div class="contact-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="contact-adress">
                            <div class="contact-detail">
                                <h2>Contact Us</h2>
                            </div>
                            <p><span><i class="fa fa-clock-o"></i></span>6 Day a week 9:00 AM to 05:00 PM</p>
                            <p><span><i class="fa fa-envelope"></i></span>sales@readysms.net</p>
                            <p><span><i class="fa fa-phone"></i></span>+191 88 444 178</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-form">
                            <h2>Get in Touch</h2>
                            <hr>
                            <form action="" method="POST">
                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="user"
                                            id="Input1" placeholder="Name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" name="email"
                                            id="Input2" placeholder="Email">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <textarea class="form-control" name="message" id="Textarea"
                                            placeholder="Message" rows="3"></textarea>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block btnsubmit">Submit</button>
                            </form>
                        </div>
                        <!-- <div class="contact-form">
                            <h2>Get in Touch</h2>
                            <hr>
                            <div class="form mb-3">
                                <input type="name" class="form-control" id="exampleFormControlInput1"
                                    placeholder="Name">
                            </div>
                            <div class="mb-3">
                                <input type="email" class="form-control" id="exampleFormControlInput2"
                                    placeholder="Email">
                            </div>
                            <div class="mb-3">
                                <textarea class="form-control" id="exampleFormControlTextarea3" placeholder="Message"
                                    rows="3"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block btnsubmit">Submit</button>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--------------Map section-------------->
    <div class="map-section">
        <!-- <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3321.056431959321!2d73.05205911468828!3d33.65569964597094!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38df9503cc61c0ff%3A0xe4fc7c20f8fbc239!2sWeb%20Development%20Company%20in%20Pakistan%20(Swismax%20Solution)!5e0!3m2!1sen!2s!4v1624962180945!5m2!1sen!2s"
            width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe> -->
    </div>
