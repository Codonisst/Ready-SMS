<!DOCTYPE html>
<html lang="en">

<head>
    <title>ReadySMS-faq's</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Latest compiled and minified JavaScript -->
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css">
    <!-- Font-Awesome icons-->
    <link rel="stylesheet" href=https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css> <link
        rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60e5f0a9d6e7610a49aa2104/1fa138618';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<style>
    .faq-backgroundimage {
        background-image: url(assets/img/faq-background-page.PNG);
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        min-height: 720px;
        position: relative;
        max-width: 100%;
    }

    .faq-backgroundimage h2 {
        text-align: center;
        color: #fff;
        font-weight: 700;
    }

    .faq-page .card-header a {
        color: #fff;
        font-size: 17px;
        white-space: normal !important;
        font-weight: 600;
        text-decoration: none;
    }

    .faq-page .card-header {
        background: #03BFCB;
    }

    .faq-page-form {
    background-color: #F9FAFA;
    padding: 20px 5px 33px 5px;
}

    .form-row input {
        width: 100%;
        max-width: 510px;
        height: 50px;
        border-radius: 0;
        margin-top: 15px;
        background-color: transparent;
    }

    .form-control::placeholder {
        font-size: 17px;
        color: #8A8A8A;
        font-weight: 400;
        opacity: 1;
    }

    .form-control {
        height: 170px;
        border-radius: 0;
        border: 2px solid #ced4da;
        resize: none;
        background-color: transparent;
    }

    #contact-btn {
        /* font-size: 15px; */
        width: 100%;
        max-width: 510px;
        height: 51px;
        margin-top: 14px;
        text-transform: uppercase;
        border-color: #ffffff;
        border-radius: 0;
        font-weight: 500;
    }

    /* .form-row span {
        display: block;
        text-align: end;
        margin-top: 9px;
        background-color: #03BFCB;
    } */

    .form-title {
        text-align: center;
    }

    .form-title h1 {
        font-weight: 700;
    }
</style>

<body>


    <div class="navigation-bar">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#"><img src="assets/img/logo.svg"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-sms.php">BULK SMS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutus.php">ABOUT US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-software.php">BULK SOFTWARE</a>
                        </li>
                        <!--<li class="nav-item">
                            <a class="nav-link" href="bulk-packages.php">BULK PACKAGES</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="faq.php">FAQ's</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us.php">CONTACT US</a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="http://72.21.24.203:90/Readyfone/"><button type="btn" class="login-btn" id="btn">LOGIN</button></a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="https://readysms.net/portal"><button type="btn" id="btn">LOGIN RESELLER</button></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>


    <div class="faq-page">
        <div class="page-title">
            <h2>FAQ's</h2>
        </div>
        <div class="container">
            <div class="card mt-3">
                <div class="card-header">
                    <a class="btn btn-link" data-toggle="collapse" href="#multiCollapseExample1" aria-expanded="false"
                        aria-controls="multiCollapseExample1">What is virtual HR and Payroll</a>
                </div>
                <div class="collapse multi-collapse" id="multiCollapseExample1">
                    <div class="card card-body">
                        <p>If you’re a small business or startup, there are a range of HR activities you need to do, the
                            Virtual HR team does this for you virtually. When you outsource your HR and payroll needs,
                            then
                            virtual HR and payroll is a simple and effective option for you. Instead of hiring multiple
                            employees in your office, you can have access to a team of dedicated payroll and human
                            resource
                            specialists by using the services. Virtual HR and payroll provide exactly the same types of
                            services you would get from a full-time, in-house payroll or HR specialist.<br>
                            A few services offered by virtual HR:</p>
                        <ul>
                            <li>Onboarding and offboarding of employees</li>
                            <li>Administration and implementation benefits</li>
                            <li>Best-practices and policy development</li>
                            <li>File auditing of all employees</li>
                            <li>Handbook development or updating</li>
                        </ul>

                        <p>A few services provided by virtual payroll:</p>

                        <ul>
                            <li>New hire reporting</li>
                            <li>Complete payroll processing</li>
                            <li>SIF file generation</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card mt">
                <div class="card-header">
                    <a class="btn btn-link" data-toggle="collapse" href="#multiCollapseExample2" aria-expanded="false"
                        aria-controls="multiCollapseExample2">What are the benefits of virtual HR and Payroll?</a>
                </div>
                <div class="collapse multi-collapse" id="multiCollapseExample2">
                    <div class="card card-body">
                        <p>If you’re a small business or startup, there are a range of HR activities you need to do, the
                            Virtual HR team does this for you virtually. When you outsource your HR and payroll needs,
                            then
                            virtual HR and payroll is a simple and effective option for you. Instead of hiring multiple
                            employees in your office, you can have access to a team of dedicated payroll and human
                            resource
                            specialists by using the services. Virtual HR and payroll provide exactly the same types of
                            services you would get from a full-time, in-house payroll or HR specialist.<br>
                            A few services offered by virtual HR:</p>

                        <ul>
                            <li>Onboarding and offboarding of employees</li>
                            <li>Administration and implementation benefits</li>
                            <li>Best-practices and policy development</li>
                            <li>File auditing of all employees</li>
                            <li>Handbook development or updating</li>
                        </ul>

                        <p>A few services provided by virtual payroll:</p>

                        <ul>
                            <li>New hire reporting</li>
                            <li>Complete payroll processing</li>
                            <li>SIF file generation</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card mt">
                <div class="card-header">
                    <a class="btn btn-link" data-toggle="collapse" href="#multiCollapseExample3" aria-expanded="false"
                        aria-controls="multiCollapseExample3">Where is my data housed and How secure it?</a>
                </div>
                <div class="collapse multi-collapse" id="multiCollapseExample3">
                    <div class="card card-body">
                        <p>If you’re a small business or startup, there are a range of HR activities you need to do, the
                            Virtual HR team does this for you virtually. When you outsource your HR and payroll needs,
                            then
                            virtual HR and payroll is a simple and effective option for you. Instead of hiring multiple
                            employees in your office, you can have access to a team of dedicated payroll and human
                            resource
                            specialists by using the services. Virtual HR and payroll provide exactly the same types of
                            services you would get from a full-time, in-house payroll or HR specialist.<br>
                            A few services offered by virtual HR:</p>

                        <ul>
                            <li>Onboarding and offboarding of employees</li>
                            <li>Administration and implementation benefits</li>
                            <li>Best-practices and policy development</li>
                            <li>File auditing of all employees</li>
                            <li>Handbook development or updating</li>
                        </ul>

                        <p>A few services provided by virtual payroll:</p>

                        <ul>
                            <li>New hire reporting</li>
                            <li>Complete payroll processing</li>
                            <li>SIF file generation</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card mt">
                <div class="card-header">
                    <a class="btn btn-link" data-toggle="collapse" href="#multiCollapseExample4" aria-expanded="false"
                        aria-controls="multiCollapseExample4">How Custumizable is Bright Minds Sulotion</a>
                </div>
                <div class="collapse multi-collapse" id="multiCollapseExample4">
                    <div class="card card-body">
                        <p>If you’re a small business or startup, there are a range of HR activities you need to do, the
                            Virtual HR team does this for you virtually. When you outsource your HR and payroll needs,
                            then
                            virtual HR and payroll is a simple and effective option for you. Instead of hiring multiple
                            employees in your office, you can have access to a team of dedicated payroll and human
                            resource
                            specialists by using the services. Virtual HR and payroll provide exactly the same types of
                            services you would get from a full-time, in-house payroll or HR specialist.<br>
                            A few services offered by virtual HR:</p>

                        <ul>
                            <li>Onboarding and offboarding of employees</li>
                            <li>Administration and implementation benefits</li>
                            <li>Best-practices and policy development</li>
                            <li>File auditing of all employees</li>
                            <li>Handbook development or updating</li>
                        </ul>

                        <p>A few services provided by virtual payroll:</p>

                        <ul>
                            <li>New hire reporting</li>
                            <li>Complete payroll processing</li>
                            <li>SIF file generation</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card mt">
                <div class="card-header">
                    <a class="btn btn-link" data-toggle="collapse" href="#multiCollapseExample5" aria-expanded="false"
                        aria-controls="multiCollapseExample5">What are the main feature of virtual HR</a>
                </div>
                <div class="collapse multi-collapse" id="multiCollapseExample5">
                    <div class="card card-body">
                        <p>If you’re a small business or startup, there are a range of HR activities you need to do, the
                            Virtual HR team does this for you virtually. When you outsource your HR and payroll needs,
                            then
                            virtual HR and payroll is a simple and effective option for you. Instead of hiring multiple
                            employees in your office, you can have access to a team of dedicated payroll and human
                            resource
                            specialists by using the services. Virtual HR and payroll provide exactly the same types of
                            services you would get from a full-time, in-house payroll or HR specialist.<br>
                            A few services offered by virtual HR:</p>

                        <ul>
                            <li>Onboarding and offboarding of employees</li>
                            <li>Administration and implementation benefits</li>
                            <li>Best-practices and policy development</li>
                            <li>File auditing of all employees</li>
                            <li>Handbook development or updating</li>
                        </ul>

                        <p>A few services provided by virtual payroll:</p>

                        <ul>
                            <li>New hire reporting</li>
                            <li>Complete payroll processing</li>
                            <li>SIF file generation</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card mt">
                <div class="card-header">
                    <a class="btn btn-link" data-toggle="collapse" href="#multiCollapseExample6" aria-expanded="false"
                        aria-controls="multiCollapseExample6">Does Bright Minds Solution have time tracking</a>
                </div>
                <div class="collapse multi-collapse" id="multiCollapseExample6">
                    <div class="card card-body">
                        <p>If you’re a small business or startup, there are a range of HR activities you need to do, the
                            Virtual HR team does this for you virtually. When you outsource your HR and payroll needs,
                            then
                            virtual HR and payroll is a simple and effective option for you. Instead of hiring multiple
                            employees in your office, you can have access to a team of dedicated payroll and human
                            resource
                            specialists by using the services. Virtual HR and payroll provide exactly the same types of
                            services you would get from a full-time, in-house payroll or HR specialist.<br>
                            A few services offered by virtual HR:</p>

                        <ul>
                            <li>Onboarding and offboarding of employees</li>
                            <li>Administration and implementation benefits</li>
                            <li>Best-practices and policy development</li>
                            <li>File auditing of all employees</li>
                            <li>Handbook development or updating</li>
                        </ul>

                        <p>A few services provided by virtual payroll:</p>

                        <ul>
                            <li>New hire reporting</li>
                            <li>Complete payroll processing</li>
                            <li>SIF file generation</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="faq-page-form mt-5">
        <div class="form-title">
            <h1>Stay Connected</h1>
            <p>Get regular news, opinions and trends from the world of HR and Recruitment.</p>
        </div>
        <div class="container">
            <form method="" action="" name="contact_form" onsubmit="return validateform()">
                <div class="form-row">
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="form_name" placeholder="First Name">
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="form_name" placeholder="Last Name">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="form_email" placeholder="Enter email">
                    </div>
                    <div class="col-md-6">
                        <button class="btn btn-info" id="contact-btn">Subscribe</button>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <div class="faq-social-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>Follow Us Social Media</h2>
                </div>
                <div class="col-md-6">

                </div>
            </div>
        </div>
    </div>


    <!-- ----------FOOTER SECTION ------------ -->
    <footer class="footer-section">
        <div class="container">
            <div class="footer-bottom">
                <div class="row pt-5">
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_mail.svg" alt="Image">
                                        <p>sales@readysms.net</p>
                                        <span>Our Mailbox</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="social-links contact-links mt-5">
                            <ul class="abc">
                                <li><a href="https://wa.me/0019188444178"><i class="fa fa-whatsapp"></i></a></li>
                                <li><a href="https://facebook.com/readysms/"><i class="fa fa-facebook-f"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_call.svg" alt="Image">
                                        <p>+191 88 444 178</p>
                                        <span>Our Phone</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="copyrights">
                    <p>Copyrights 2019 © ReadySMS, Designed and Developed by Swismax Solution All
                        rights reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <!---------------------- THE END ---------------------------->

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="" src="assets/js/owl.carousel.min.js"></script>
    <script type="" src="assets/js/owl.carousel.setting.js"></script>
    <script type="" src="assets/js/main.js"></script>
</body>

</html>