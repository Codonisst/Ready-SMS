<!DOCTYPE html>
<html lang="en">

<head>
    <title>Ready sms</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Latest compiled and minified JavaScript -->
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css">
    <!-- Font-Awesome icons-->
    <link rel="stylesheet" href=https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css> <link
        rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60e5908bd6e7610a49aa0eac/1fa0bp8rv';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</head>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60e5f0a9d6e7610a49aa2104/1fa138618';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<body>

     <!------------HEADER--------------->
    <div class="navigation-bar">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#"><img src="assets/img/logo.svg"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-sms.php">BULK SMS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutus.php">ABOUT US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-software.php">BULK SOFTWARE</a>
                        </li>
                        <!--<li class="nav-item">
                            <a class="nav-link" href="bulk-packages.php">BULK PACKAGES</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="faq.php">FAQ's</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us.php">CONTACT US</a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="http://72.21.24.203:90/Readyfone/"><button type="btn" class="login-btn" id="btn">LOGIN</button></a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="https://readysms.net/portal"><button type="btn" id="btn">LOGIN RESELLER</button></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <!---------HERO SECTION-------------->
    <section class="hero-section">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/img/slide_02.png" class="d-block w-100" alt="Image">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slide_02.png" class="d-block w-100" alt="Image">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slide_02.png" class="d-block w-100" alt="Image">
                </div>
            </div>
            <!-- <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon arrow" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon arrow" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a> -->
        </div>
    </section>

    <!------------- REGISTRAION SECTION --------------->
    <section class="registration-section">
        <div class="container">
            <div class="row reg-content">
                <div class="col-md-7">
                    <h3>ReadySMS allows you to quickly and easily send SMS</h3>
                    <p>ReadySMS providing Bulk SMS services for all types of marketing, promotional, branding, advertising & Transactional purposes. With ReadySMS you can access thousands clients within seconds to share a single message with all. Our Fast services will touch in few seconds to your receiver contacts.</p>
                </div>
                <div class="col-md-5">
                    <div class="reg-icon">
                        <a href="callto:+123123123"><img src="assets/img/readyfon.png" alt="image-butten"></a> &nbsp;
                        <a href="contact-us.php"><img src="assets/img/icon_getintouch.svg" alt="image-butten"></a>
                    </div>                
                    <!-- <p>ReadySMS providing Bulk SMS services for all types of marketing, promotional, branding, advertising & Transactional purposes. With ReadySMS you can access thousands clients within seconds to share a single message with all. Our Fast services will touch in few seconds to your receiver contacts.</p> -->
                </div>
            </div>
        </div>
    </section>

    <!-- -------- FEATURED SECTION ---------- -->
    <section class="feature-app">
        <div class="container">
            <h2 class="section-title mt-5">Our App Features
                <hr>
            </h2>
            <div class="row mt-5">
                <div class="col-md-6">
                    <div class="feature-portal">
                        <ul>
                            <li><a href="#"><img src="assets/img/feature_icon_01.svg" alt="Image">
                                    <div class="feature-text">
                                        <b>
                                            <p>BULK SMS</p>
                                        </b>
                                        <span>Send Transactional & Promotional SMS</span>
                                    </div>
                                </a></li>
                            <li><a href="#"><img src="assets/img/feature_icon_02.svg" alt="Image">
                                    <div class="feature-text">
                                        <b>
                                            <p>API SMS</p>
                                        </b>
                                        <span>Send OTP & Notification via SMS API</span>
                                    </div>
                                </a></li>
                            <li><a href="#"><img src="assets/img/feature_icon_03.svg" alt="Image">
                                    <div class="feature-text">
                                        <b>
                                            <p>SCHEDULED SMS</p>
                                        </b>
                                        <span>Sheduled Your SMS for Future Reminders</span>
                                    </div>
                                </a></li>
                            <li><a href="#"><img src="assets/img/feature_icon_04.svg" alt="Image">
                                    <div class="feature-text">
                                        <b>
                                            <p>CUSTOM SMS</p>
                                        </b>
                                        <span>Import Bulk Data From Your Excil File</span>
                                    </div>
                                </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-image">
                        <img src="assets/img/ourportal.png" alt="Image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- -----------DIGIT SECTION ------------->
    <!-- <section class="digits-section mt-5">
        <div class="container">
            <div class="row digit-item">
                <div class="col-md-4">
                    <div class="digit-text">
                        <h2><img src="assets/img/counter_icon.svg" alt="image-icon"> Doing the right thing, at the right
                            time.</h2>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="3000" data-speed="1500">5,426</h2>
                                <p class="count-text ">Clients</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="105" data-speed="1500">256</h2>
                                <p class="count-text ">Countries</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="1589" data-speed="1500">1,589</h2>
                                <p class="count-text ">SMS Sents</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="568" data-speed="1500">289</h2>
                                <p class="count-text ">Corporate Componies</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <section class="digits-section pb-5">
        <div class="container">
            <div class="digit-item">
                <div class="digit-text">
                    <img src="assets/img/counter_icon.svg" alt="image-icon"> &nbsp;
                    <h2> Doing the right thing, at the
                        right time.</h2>
                </div>
                <div class="digit-counter" id="clients-timer">
                    <div class="counter">
                        <h2 class="timer count-title count-number" data-to="3000" data-speed="1500">5,426</h2>
                        <p class="count-text ">Clients</p>
                    </div>
                    <div class="counter">
                        <h2 class="timer count-title count-number" data-to="105" data-speed="1500">256</h2>
                        <p class="count-text ">Countries</p>
                    </div>
                    <div class="counter">
                        <h2 class="timer count-title count-number" data-to="2983309" data-speed="1500">1,589</h2>
                        <p class="count-text ">SMS Sents</p>
                    </div>
                    <div class="counter">
                        <h2 class="timer count-title count-number" data-to="568" data-speed="1500">289</h2>
                        <p class="count-text ">Corporate Componies</p>
                    </div>
                </div>
                <!-- <div class="digit-timer">

                        </div> -->
                <!-- <div class="col-md-2">
                        <div class="counter">
                            <h2 class="timer count-title count-number" data-to="3000" data-speed="1500">5,426</h2>
                            <p class="count-text ">Clients</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="counter">
                            <h2 class="timer count-title count-number" data-to="105" data-speed="1500">256</h2>
                            <p class="count-text ">Countries</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="counter">
                            <h2 class="timer count-title count-number" data-to="2983309" data-speed="1500">1,589</h2>
                            <p class="count-text ">SMS Sents</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="counter">
                            <h2 class="timer count-title count-number" data-to="568" data-speed="1500">289</h2>
                            <p class="count-text ">Corporate Componies</p>
                        </div>
                    </div> -->

            </div>
        </div>
    </section>

    <!-- ----------FOOTER SECTION ------------ -->
    <footer class="footer-section">
        <div class="container">
            <div class="footer-bottom">
                <div class="row pt-5">
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_mail.svg" alt="Image">
                                        <p>sales@readysms.net</p>
                                        <span>Our Mailbox</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="social-links contact-links mt-5">
                            <ul class="abc">
                                <li><a href="https://wa.me/0019188444178"><i class="fa fa-whatsapp"></i></a></li>
                                <li><a href="https://facebook.com/readysms/"><i class="fa fa-facebook-f"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_call.svg" alt="Image">
                                        <p>+191 88 444 178</p>
                                        <span>Our Phone</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="copyrights">
                    <p>Copyrights 2019 © ReadySMS, Designed and Developed by Swismax Solution All
                        rights reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <!---------------------- THE END ---------------------------->

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="" src="assets/js/owl.carousel.min.js"></script>
    <script type="" src="assets/js/owl.carousel.setting.js"></script>
    <script type="" src="assets/js/main.js"></script>
</body>

</html>