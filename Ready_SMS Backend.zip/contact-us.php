<!DOCTYPE html>
<html lang="en">

<head>
    <title>Contact Us</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Latest compiled and minified JavaScript -->
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css">
    <!-- Font-Awesome icons-->
    <link rel="stylesheet" href=https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css> <link
        rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60e5f0a9d6e7610a49aa2104/1fa138618';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
     <!----------------HEADER-------------------->
     <div class="navigation-bar">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#"><img src="assets/img/logo.svg"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-sms.php">BULK SMS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutus.php">ABOUT US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-software.php">BULK SOFTWARE</a>
                        </li>
                        <!--<li class="nav-item">
                            <a class="nav-link" href="bulk-packages.php">BULK PACKAGES</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="faq.php">FAQ's</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us.php">CONTACT US</a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="http://72.21.24.203:90/Readyfone/"><button type="btn" class="login-btn" id="btn">LOGIN</button></a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="https://readysms.net/portal"><button type="btn" id="btn">LOGIN RESELLER</button></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
     <!--------------CONTACT US PAGE-------------->
    <section class="contact-section">
        <div class="page-title">
            <h2>Contact Us</h2>
        </div>
        <div class="contact-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="contact-adress">
                            <div class="contact-detail">
                                <h2>Contact Us</h2>
                            </div>
                            <p><span><i class="fa fa-clock-o"></i></span>6 Day a week 9:00 AM to 05:00 PM</p>
                            <p><span><i class="fa fa-envelope"></i></span>sales@readysms.net</p>
                            <p><span><i class="fa fa-phone"></i></span>+191 88 444 178</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-form">
                            <h2>Get in Touch</h2>
                            <hr>
                            <form action="" method="POST">
                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="user"
                                            id="Input1" placeholder="Name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" name="email"
                                            id="Input2" placeholder="Email">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <textarea class="form-control" name="message" id="Textarea"
                                            placeholder="Message" rows="3"></textarea>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block btnsubmit">Submit</button>
                            </form>
                        </div>
                        <!-- <div class="contact-form">
                            <h2>Get in Touch</h2>
                            <hr>
                            <div class="form mb-3">
                                <input type="name" class="form-control" id="exampleFormControlInput1"
                                    placeholder="Name">
                            </div>
                            <div class="mb-3">
                                <input type="email" class="form-control" id="exampleFormControlInput2"
                                    placeholder="Email">
                            </div>
                            <div class="mb-3">
                                <textarea class="form-control" id="exampleFormControlTextarea3" placeholder="Message"
                                    rows="3"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block btnsubmit">Submit</button>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--------------Map section-------------->
    <div class="map-section">
        <!-- <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3321.056431959321!2d73.05205911468828!3d33.65569964597094!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38df9503cc61c0ff%3A0xe4fc7c20f8fbc239!2sWeb%20Development%20Company%20in%20Pakistan%20(Swismax%20Solution)!5e0!3m2!1sen!2s!4v1624962180945!5m2!1sen!2s"
            width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe> -->
    </div>

    <!-- ----------FOOTER SECTION ------------ -->
    <footer class="footer-section">
        <div class="container">
            <div class="footer-bottom">
                <div class="row pt-5">
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_mail.svg" alt="Image">
                                        <p>sales@readysms.net</p>
                                        <span>Our Mailbox</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="social-links contact-links mt-5">
                            <ul class="abc">
                                <li><a href="https://wa.me/0019188444178"><i class="fa fa-whatsapp"></i></a></li>
                                <li><a href="https://facebook.com/readysms/"><i class="fa fa-facebook-f"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_call.svg" alt="Image">
                                        <p>+191 88 444 178</p>
                                        <span>Our Phone</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="copyrights">
                    <p>Copyrights 2019 © ReadySMS, Designed and Developed by Swismax Solution All
                        rights reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <!---------------------- THE END ---------------------------->

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="" src="assets/js/owl.carousel.min.js"></script>
    <script type="" src="assets/js/owl.carousel.setting.js"></script>
    <script type="" src="assets/js/main.js"></script>
</body>

</html>