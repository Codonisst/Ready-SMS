<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bulk sms</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Latest compiled and minified JavaScript -->
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css">
    <!-- Font-Awesome icons-->
    <link rel="stylesheet" href=https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css> <link
        rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60e5f0a9d6e7610a49aa2104/1fa138618';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
    <!----------------HEADER-------------------->
    <div class="navigation-bar">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#"><img src="assets/img/logo.svg"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-sms.php">BULK SMS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutus.php">ABOUT US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bulk-software.php">BULK SOFTWARE</a>
                        </li>
                        <!--<li class="nav-item">
                            <a class="nav-link" href="bulk-packages.php">BULK PACKAGES</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="faq.php">FAQ's</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us.php">CONTACT US</a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="http://72.21.24.203:90/Readyfone/"><button type="btn" class="login-btn" id="btn">LOGIN</button></a>
                        </li>
                        <li class="nav-item">                           
                            <a class="nav-link" href="https://readysms.net/portal"><button type="btn" id="btn">LOGIN RESELLER</button></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
    <!------------- BULK SMS PAGE --------------->
    <div class="bulk-sms-page">
        <div class="page-title">
            <h2>BULK SMS</h2>
        </div>
        <div class="bulk-page">
            <div class="container">
                <div class="bulk-content">
                    <div class="free-testing">
                        <!-- <h1>🥇BEST BULK SMS SERVICE PROVIDER IN INDIA (FREE TESTING)</h1> -->
                        <p><b>Bulk SMS</b> needs no introduction. We all know that SMS stands for Short Messaging
                            Service.
                            Basically it means sending text messages from phone/laptop to another phone and when we send
                            SMS
                            to group of people then it called as Bulk SMS. To send SMS people use <b>Bulk SMS
                                service.</b>
                        </p>
                    </div>
                    <div class="send-sms">
                        <a href="contact-us.php"><img src="assets/img/send-sms.png" alt="Image"></a>
                    </div>
                    <div class="bulk-text">
                        <!-- <p><b>What exactly is bulk SMS?</b> And what are the kinds of bulk SMS which are getting so
                            popular that every business or industry is planning to implement <a href="#">bulk SMS
                                advertising</a> strategy? Let’s dig deep into these questions.</p>

                        <h3>What is bulk SMS service?</h3>
                        <p>Wikipedia defines bulk SMS as the dissemination of large number of SMS messages for delivery
                            to mobile phone terminals. To put in simple words it means that bulk SMS is sending SMS to
                            large number of recipients at once. Bulk SMS can be used to send reminders, alerts, update
                            clients about new offers, deals, and discounts. These days it is widely used for promotion
                            and advertising of products and services. <br>
                            There is no limit to the use of bulk SMS. Its uses are endless. Bulk SMS can be deployed
                            wherever we need to build an instant connection and convey urgent information.</p> -->
                        <h3>Types of Bulk SMS Service</h3>
                        <ol>
                            <li>
                                <p><b>Transactional Bulk SMS Service</b> – These SMS are used for conveying certain
                                    urgent and necessary information. Example when message comes from a bank informing
                                    you about the amount credited or debited. Similarly when you make an online
                                    purchase, its details like invoice number, delivery status are being conveyed to you
                                    via an SMS.

                                </p>

                                <p><b>Example</b> <br> Dear Customer Rs. 500 was spent on Card no xxxx7899xxxx at
                                    Mumbai. Available balance in your account is Rs. 1000.</p>
                                <p>Dear Customer Your Amazon order is out for delivery. Please share the OTP 122944 with
                                    the Delivery agent to get the package.</p>
                            </li>
                            <li>
                                <p><b>Promotional Bulk SMS Service</b> – The basic purpose of the promotional SMS is to
                                    advertise a business and market its products and services. As per TRAI regulations,
                                    promotional SMS can be sent only to non DND number within a time frame of 9 AM to 9
                                    PM.</p>

                                <p> <b>Example</b> <br> Buy 2 kitchen appliances and get 1 at 50% discount. Hurry up.
                                    Offer valid till the stock lasts.</p>
                                <p> Now you must be clear regarding the difference between the <b>promotional and the
                                        transactional Bulk SMS.</b> Let’s compare <b>bulk SMS marketing</b> with other
                                    prevailing forms of marketing.</p>
                            </li>
                        </ol>
                        <h3>Bulk SMS vs email marketing</h3>
                        <p>There is a lot of debate on the topic whether to go for bulk SMS or email marketing. Let’s
                            look into some facts related to email and SMS:</p>
                        <div class="email image">
                            <a href="#"><img src="assets/img/text-read.png" alt="Image"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- ----------FOOTER SECTION ------------ -->
    <footer class="footer-section">
        <div class="container">
            <div class="footer-bottom">
                <div class="row pt-5">
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_mail.svg" alt="Image">
                                        <p>sales@readysms.net</p>
                                        <span>Our Mailbox</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="social-links contact-links mt-5">
                            <ul class="abc">
                                <li><a href="https://wa.me/0019188444178"><i class="fa fa-whatsapp"></i></a></li>
                                <li><a href="https://facebook.com/readysms/"><i class="fa fa-facebook-f"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-links">
                            <ul class="abc">
                                <li><a href="#"><img src="assets/img/icon_call.svg" alt="Image">
                                        <p>+191 88 444 178</p>
                                        <span>Our Phone</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="copyrights">
                    <p>Copyrights 2019 © ReadySMS, Designed and Developed by Swismax Solution All
                        rights reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <!---------------------- THE END ---------------------------->

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="" src="assets/js/owl.carousel.min.js"></script>
    <script type="" src="assets/js/owl.carousel.setting.js"></script>
    <script type="" src="assets/js/main.js"></script>
</body>

</html>